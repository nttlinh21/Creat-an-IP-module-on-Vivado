#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xuartlite.h"
#include "MIN.h"
#include "xil_io.h"
#include "xparameters.h"
#include <stdlib.h>

#define UART_DEVICE_ID XPAR_AXI_UARTLITE_0_DEVICE_ID
#define MIN_DEVICE_BASEADDR XPAR_MIN_0_S_AXI_BASEADDR

XUartLite uart;
XUartLite_Config *uart_config;


void uart_init() {
    uart_config = XUartLite_LookupConfig(UART_DEVICE_ID);
    int status = XUartLite_CfgInitialize(&uart, uart_config, uart_config->RegBaseAddr);
    if (status != XST_SUCCESS) {
        xil_printf("UART INIT FAILED\n");
        while (1);
    }
    xil_printf("UART INIT SUCCESSFUL\n");
}


void uart_receive_line(char *buffer, int max_length) {
    int idx = 0;
    u8 byte;
    while (idx < max_length - 1) {
        if (XUartLite_Recv(&uart, &byte, 1) == 1) {
            if (byte == '\r') {
                buffer[idx] = '\0';
                xil_printf("\n");
                return;
            }
            buffer[idx++] = byte;
            xil_printf("%c", byte);
        }
    }
    buffer[idx] = '\0';
}


int is_valid_input(int value) {
    return value >= -128 && value <= 127;
}

int main() {
    init_platform();
    uart_init();

    char buffer_a[10], buffer_b[10];
    int input_a, input_b;
    s8 result;

    while (1) {
        xil_printf("Nhap so a (trong khoang -128 den 127): ");
        uart_receive_line(buffer_a, sizeof(buffer_a));
        input_a = atoi(buffer_a);
        if (!is_valid_input(input_a)) {
            xil_printf("Gia tri khong hop le. Vui long nhap lai!\n");
            continue;
        }

        xil_printf("Nhap so b (trong khoang -128 den 127): ");
        uart_receive_line(buffer_b, sizeof(buffer_b));
        input_b = atoi(buffer_b);
        if (!is_valid_input(input_b)) {
            xil_printf("Gia tri khong hop le. Vui long nhap lai!\n");
            continue;
        }


        MIN_mWriteReg(MIN_DEVICE_BASEADDR, MIN_S_AXI_SLV_REG0_OFFSET, (u32)input_a);
        MIN_mWriteReg(MIN_DEVICE_BASEADDR, MIN_S_AXI_SLV_REG1_OFFSET, (u32)input_b);


        usleep(1000);


        u32 raw_result = MIN_mReadReg(MIN_DEVICE_BASEADDR, MIN_S_AXI_SLV_REG2_OFFSET);
        xil_printf("Gia tri doc duoc (raw): 0x%X\n", raw_result);
        result = (s8)raw_result;


        xil_printf("So nho hon la: %d\n\n", result);
    }

    cleanup_platform();
    return 0;
}
